/*
console.log('卖煎饼嘞');
console.log('又香又脆的煎饼');
console.log('40块一套');
*/

//创建函数
function laba(){
  //函数体
  console.log('卖煎饼嘞');
  console.log('又香又脆的煎饼');
  console.log('80块一套');
}
//调用
//laba();
//laba();
//laba();

//练习：创建函数getSum，封装计算1~100之间所有整数的和，并调用多次
function getSum(){
  //函数体
  for(var i=1,sum=0;i<=100;i++){
    sum+=i;
  }
  console.log(sum);
}
//调用
//getSum();
//getSum();
//getSum();









