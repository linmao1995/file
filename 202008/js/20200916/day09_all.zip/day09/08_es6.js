function add(a,b,c=0){//参数增强
  console.log(a+b+c);
}
add(6000,5000,1000);
add(6000,3000);