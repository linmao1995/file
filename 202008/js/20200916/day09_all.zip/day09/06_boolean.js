var b1=true;//字面量
//强制转为布尔型
//0 NaN undefined null ''
var b2=new Boolean(0);
var b3=Boolean(NaN);//推荐
//console.log(b2,typeof b2);
//console.log(b3);
//空数组，空的自定义对象
var arr=[];//true
console.log( Boolean(arr) );