/*
//创建Date对象
var d1=new Date('2020/9/16 10:37:45');
var d2=new Date(2020,8,16,10,37,45);//月份 0~11  1月~12月
var d3=new Date();//当前操作系统时间
var d4=new Date(1576800000000);
//console.log(d4);
//1576800000000

var d=new Date('2020/9/16 10:57:30');
console.log( d.getFullYear() );
console.log( d.getMonth()+1 );//0~11
console.log( d.getDate() );
console.log( d.getHours() );
console.log( d.getMilliseconds() );
console.log( d.getDay() );//0~6  星期日~星期六
console.log( d.getTime() );


//练习：创建Date对象，保存当前的系统时间，获取日期时间，打印出以下格式
//xxxx年xx月xx日 11点30分01秒  星期三
var now=new Date();
var year=now.getFullYear();
var month=now.getMonth()+1;
var date=now.getDate();
var hour=now.getHours();
var minute=now.getMinutes();
var second=now.getSeconds();
var day=now.getDay();//0~6
var arr=['日','一','二','三','四','五','六'];
//arr[day]
//如果秒钟小于10，则在前拼接0 
if(second<10){
  second='0'+second;  //02
}
console.log(year+'年'+month+'月'+date+'日 '+hour+'点'+minute+'分'+second+'秒 星期'+arr[day]);
*/

//计算距离2020年国庆节还有 x天x小时x分x秒
var d1=new Date('2020/10/1');//国庆节
var d2=new Date();//当前时间
//相差的毫秒数
var d=d1.getTime()-d2.getTime();
//两个Date对象相减得到的也是相差的毫秒数
//console.log(d1-d2);
//把单位由毫秒转为秒
//相差的秒数
d=parseInt(d/1000);
//计算相差的天数=相差的秒数/每天的秒数
var day=parseInt( d/(24*60*60) );
//计算相差的小时，总的相差的秒数-14天的秒数，剩余的秒数转为小时
var hour=d-day*24*60*60;
//通过取余的方式去除天数
//去除相差的秒数中含有的天数
//console.log( d%(24*60*60) );
//换算为小时
hour=parseInt( hour/(60*60) );
//计算相差的分钟，总的相差秒数-14天秒数-9小时的秒数，换算为分钟
var minute=d-day*24*60*60-hour*60*60;
//通过取余，去除小时
//console.log( d%(60*60) );
//换算为分钟
minute=parseInt(minute/60);
//计算相差的秒钟=总的相差秒数-14天秒数-9小时秒数-25分钟秒数
var second=d-day*24*60*60-hour*60*60-minute*60;
//通过取余，去除分钟
//console.log(d%60);
console.log(day+'天'+hour+'小时'+minute+'分'+second+'秒');

