/*
//转为本地字符串格式（了解）
var d=new Date();
console.log( d.toLocaleString() );
console.log( d.toLocaleDateString() );
console.log( d.toLocaleTimeString() );

//设置日期时间
var d=new Date('2020/1/16 10:30:40');
//
//d.setFullYear(2021);
//d.setMonth(0);  //0~11
//一周后
//3个月前：当前月份的基础之上减3
//d.setMonth( d.getMonth()-3 );
//毫秒
d.setTime(1576800000000);

console.log( d.toLocaleString() );
*/

//创建对象保存一个员工的入职时间
var d1=new Date('2020/9/20');
//练习：假如合同期为3年，计算出合同的到期时间
//把入职时间复制一份，作为到期时间
var d2=new Date(d1);
//3年后合同到期
d2.setFullYear( d2.getFullYear()+3 );
//练习：合同到期前1个月要续签合同，如果是周末提前到周五，计算出合同的续签时间
//复制一份到期时间，作为续签时间
var d3=new Date(d2);
//提前一个月
d3.setMonth( d3.getMonth()-1 );
//判断是否为周末
var day=d3.getDay();
console.log(day);
if(day===6){
  //如果周六提前1天
  d3.setDate( d3.getDate()-1 );
}else if(day===0){
  //如果周日提前2天
  d3.setDate( d3.getDate()-2 );
}

console.log('入职时间：'+d1.toLocaleDateString());
console.log('到期时间：'+d2.toLocaleDateString());
console.log('续签时间：'+d3.toLocaleDateString());

