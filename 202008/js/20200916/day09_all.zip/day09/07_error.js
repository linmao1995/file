console.log(1);
/*
//var a=1；//语法错误
var b=2;
//console.log(B);//引用错误
//parseint(3.14);
var str='abc';
//console.log( str.charat(0) );//类型错误
//var arr=new Array(-2);//范围错误

var age=16;
//如果没有在合法的范围，抛出自定义的错误
if(age<18 || age>60){
  throw '非法的年龄';
}
*/
//错误处理：出现了错误，也不会阻止往后执行
var age=26;
try{
  //尝试执行，可能产生错误
  if(age<18 || age>60){
    throw '非法的年龄';
  }
}catch(err){
  //一旦try中出现了错误，会自动被捕获
  //err 会保存错误信息
  console.log(err);
  //处理错误
  age=18;
}
console.log(age);
console.log(2);