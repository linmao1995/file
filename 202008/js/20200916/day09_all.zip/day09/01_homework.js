/*
//1.将一句英文中每个单词的首字母大写，其余字母小写
var str='wHat aRE yOu dOING';
//按照空格将字符串切割为数组
var arr=str.split(' ');
//遍历数组得到每个英文单词
for(var i=0;i<arr.length;i++){
  //arr[i] 每个单词
  //将首个字符截取，转大写
  //转换以后得到的是一个新的字符串，对原来字符串没有任何影响
  var f=arr[i].substr(0,1).toUpperCase();
  //将其余的字符截取，转小写
  var o=arr[i].substr(1).toLowerCase();
  //console.log(f,o);
  //把前后两部分拼接起来组成单词，覆盖原来的单词
  arr[i]=f+o;
}
//把数组转为字符串，按照空格分割
console.log( arr.join(' ') );
*/

//2.随机获取a~z之间的4个字母，放入到一个新数组中
var arr=['a','b','c','d','e','f','g','h','i','j','k','l','m','n'];
//保存每次获取到的随机元素
var arr2=[];
//循环4次，每次获取1个随机
for(var i=0;i<4;i++){
  //0~9
  //0~1 * 10  0~9.x  取整  0~9
  var n=parseInt( Math.random()*arr.length );
  //console.log(n,arr[n]);
  //把获取的随机元素添加到数组arr2
  arr2.push( arr[n] );
}
console.log(arr2);




