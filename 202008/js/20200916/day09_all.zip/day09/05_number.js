//Number()
var n1=1;//字面量
var n2=new Number(true);
var n3=Number(false);//推荐
//console.log(n3);
//console.log(n2, typeof n2);
//console.log(n1+2, n2+2);

var n4=2*5*3.14;
//保留小数点后n位
//console.log( n4.toFixed(2) );
//购物车的总价
var n5=3199*2+420*3;
console.log( n5.toFixed(2) );
console.log( 7658.00 );
