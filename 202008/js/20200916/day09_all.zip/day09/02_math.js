//console.log( Math.PI );//圆周率
//console.log( Math.abs(3-5) );//绝对值 

//向下取整
//console.log( Math.floor(-4.99) );
//向上取整
//console.log( Math.ceil(4.01) );
//四舍五入
//console.log( Math.round(4.5) );
//获取一组数字最大值
//console.log( Math.max(23,9,78,6,45) );
//获取一组数字最小值
//console.log( Math.min(23,9,78,6,45) );
//次方
console.log( Math.pow(10,3) );

