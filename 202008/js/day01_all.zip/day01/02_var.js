//声明(定义)变量
//声明了变量x，将1赋值给变量x，把1保存到x中。
var x=1;
var num='五';
//console.log(x,num);

//练习：声明多个变量，分别保存一个员工的编号，姓名，性别，生日，工资，最后打印出来。
var eid=2;
var ename='然哥';
var sex='女';
var birthday='1977-5-29';
var salary=50000;
//console.log(eid,ename,sex,birthday,salary);

var a1=2;
var a_2=4;
var _a3=5;
var $_b4=7;
//var 然=100;
//console.log(a1,a_2,_a3,$_b4);
//console.log(然);


var hour=17;
//重新赋值
hour=18;
//弱类型语言特点
hour='十八';
//undefined 声明变量未赋值
var minute;
minute=42;
//console.log(hour,minute);

//一次声明多个变量
var a=1,b=2,c;
//console.log(a,b,c);

//练习：声明多个变量分别保存语文，数学，总成绩；打印出总成绩。
var chinese=70,math=60,total=chinese+math;
//console.log(total);


//常量
const pi=3.14;
pi=3.1415;
console.log(pi);


