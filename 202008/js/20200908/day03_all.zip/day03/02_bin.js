console.log(3&5);//1
console.log(5&7);//5
console.log(5|7);
console.log(6|9);