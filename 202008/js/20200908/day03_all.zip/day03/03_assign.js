var a=2;
//在原来基础之上加1
//a++;
//a=a+1;
//等价于 
//+=  运算赋值：先执行运算，再执行赋值
a+=3;
//console.log(a);
//练习：声明变量保存商品价格，该商品打八折，最后打印出价格
var price=100;
//在原来基础之上乘以0.8
//price=price*0.8;
price*=0.8;
console.log(price);





