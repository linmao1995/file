//判断一个是否为成年人，如果是打印‘成年人’，否则‘未成年人’
var age=19;
//age>=18 ? console.log('成年人') : console.log('未成年人');
var res=age>=18 ? '成年人' : '未成年人';
//console.log(res);

//练习：声明变量保存用户输入的用户名和密码，如果用户名是root，并且密码是123456，打印登录成功，否则打印登录失败
var uname='root';
var upwd='888888';

var res=uname==='root' && upwd==='123456' ? '登录成功' : '登录失败';
console.log(res);








