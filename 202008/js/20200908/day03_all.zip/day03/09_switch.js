/*
//1-瓦坎达   2-印度   3-日本  其它-八宝山
var n='2';
switch(n){
  case 1: 
    console.log('瓦坎达');
    break;
  case 2:
	console.log('印度');
    break;
  case 3:
	console.log('日本');
    break;
  default:
	console.log('八宝山');
}
*/
//练习：声明变量保存任意一个城市名称，打印出对应城市的特色美食
var city='长沙';
switch(city){
  case '重庆':
	console.log('火锅');
    break;
  case '长沙':
	console.log('臭豆腐');
    break;
  case '西安':
	console.log('羊肉泡馍');
    break;
  default:
	console.log('沙县小吃');
}






