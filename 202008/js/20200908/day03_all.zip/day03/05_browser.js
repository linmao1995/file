//弹出警示框
//alert('WEB2008');
//弹出提示框(输入)
//需要使用变量保存输入的内容
//var s=prompt('please input uname');
//console.log(s,typeof s);

//练习：弹出两次提示框，要求用户分别输入数字，最后计算两个数字相加的和，并将结果以警示框的形式弹出。
var n1=prompt('input num1');
var n2=prompt('input num2');
//3+5
alert(Number(n1)+Number(n2));


