/*
var str='12';
console.log( Number(str) );
//检测是否为NaN
console.log( isNaN(str) );
*/

//console.log(-2/0);//Infinity
//console.log(2/3);
//检测一个值是否为有限值
//只有无穷是无限值
//console.log( isFinite(-2/0) );//false
//console.log( isFinite(2/3) );


//onsole.log('1+2');
//执行字符串中的表达式
//console.log( eval('1+2') );
//var a='20';
//console.log( eval('a') );

console.log('parseInt(3.14)');
console.log( eval('parseInt(3.14)') );