//取余
//console.log(5%3);//2
//console.log(3%5);//3
//闰年
//console.log(2019%4);
//奇数和偶数
//console.log(3%2);
//隐式转换为数值
//console.log('5'%'3');//2

/*
var a=3;
//自增
//a++;
++a;
console.log(a);

var b=2;
//自减
b--;
console.log(b);



var c=7;
//把c的值赋给d，然后再执行自增
var d=c++;
console.log(d,c);

var e=4;
var f=++e;
console.log(f,e);



var num=6;
//var n1=num--; //6
//var n2=--num; //4
//console.log(n1+n2);
//等价于以下写法
console.log(num-- + --num);
*/

var a='1a';
//隐式转换为数值型 NaN
a++;
console.log(a);



