//判断一个人的工资是否在5000~8000之间
var salary=3000;
//console.log( salary>=5000 && salary<=8000 );
//练习：声明变量分别保存用户名和密码，如果用户名是'root'并且密码是'123456'，如果都正确打印true，否则false
var uname='range';
var upwd='123456';
//console.log( uname==='root' && upwd==='123456' );

//判断一个年龄是否符合半价票标准(60以上或者12以下)
var age=21;
//console.log(age>=60 || age<=12);
//练习：声明变量保存用户输入的值，如果输入的是用户名root,或者是游箱root@126.com，或者是手机18112345678，打印true，否则false
var input='root';
//console.log(input==='root' || input==='root@126.com' || input==='18112345678');

//逻辑非
//var a=3>1;
//var b=false;
//console.log(!a,!b);

//练习：查看以下程序是否会报错
var n=2;
n>3 && console.log(a);//短路
//n<1 || console.log(b);//报错，b找不到

//练习：声明变量保存年龄，如果满18岁，打印‘成年人’
var age=9;
age>=18  &&  console.log('成年人');





