var arr=['然哥','王涛','刘浩南',true,1];
//console.log(arr, typeof arr);

//练习：创建数组，包含有一组商品名称；创建数据，包含有一组成绩。
//var score=[70,81,65,93];
//console.log(score);
var laptop=['小米','戴尔','苹果','华为'];
//console.log(laptop);
//访问元素
//下标（索引）
//console.log( laptop[0],laptop[2],laptop[4] );
laptop[1]='thinkpad';
laptop[4]='惠普';
laptop[6]='华硕';
//console.log(laptop);

//练习：创建数组，包含有一组城市名称，修改中的元素，在末尾添加两个数组
var city=['北京','成都','杭州','广州'];
city[0]='南京';
city[3]='深圳';
city[4]='长沙';
city[5]='济南';
console.log(city);






