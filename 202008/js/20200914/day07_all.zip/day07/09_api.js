/*
var arr=['a','b','c'];
//转字符串
console.log( arr.toString() );
console.log( arr.join('') );
//只要数据类型不同，即使方法名称相同也不是同一个方法
//var num=3;
//num.toString()
*/

var arr1=['王涛','邱聪聪','李志国','刘方磊','张思遥']
var arr2=['杜江','王小明','李鑫','熊杰'];
var arr3=['卢本伟','潘清波','李相赫'];
//拼接多个数组
console.log( arr1.concat(arr2,arr3) );




