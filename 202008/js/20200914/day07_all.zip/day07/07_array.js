//关联数组
var arr=[];
arr['id']=2;
arr.name='然哥';
//console.log(arr);
//console.log(arr.length);

//练习：创建数组包含有一组员工的数据，每条员工的数据包含有编号和姓名属性
var emp=[
  {eid:1,ename:'tom'},
  {eid:2,ename:'jerry'}
];
//console.log(emp);
//练习：创建一个学生对象，包含有学号，姓名，性别，选修的多个课程
var student={
  sid:5,
  name:'然哥',
  sex:'男',
  course:['机械学','食品工程','运动学','养殖学']
}
console.log(student);




