/*
//打印1~10，不包含6
for(var i=1;i<=10;i++){
  //当i为6的时候
  if(i===6){
    //break;//结束循环，不再执行循环中任何代码
	continue;//跳过这一次循环，继续执行下一次循环
  }
  console.log(i); 
}
*/
// 练习：打印1~100之间所有的奇数，遇到偶数就跳过
for(var i=1;i<=100;i++){
  //判断i是否为偶数
  if(i%2===0){
    continue;
  }
  console.log(i);
}



