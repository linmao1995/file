//打印0~9
/*
//初始值
var i=0;
do{
  //循环体
  console.log(i);
  //增量
  i++;
}while(i<10);

//练习：打印70  65  60  55  50
var i=70;
do{
  console.log(i);
  i-=5;
}while(i>=50);

//练习：打印出1~100之间所有能被7整除的数字
var i=1;
do{
  //i代表所有的整数
  if(i%7===0){
    //如果能被7整除
	console.log(i);
  }
  i++;
}while(i<=100);

//练习：计算1~100之间所有能被3整除的数字的和
var i=1;
var sum=0;
do{
  //i代表所有的整数
  //判断是否能被3整除
  if(i%3===0){
    //求和
    sum+=i;
  }
  i++;
}while(i<=100);
//循环结束后，打印最终的结果
console.log(sum);

//练习：计算1~20之间所有偶数的乘积
var i=1;
var s=1;
do{
  //i代表所有整数
  //判断是否为偶数
  if(i%2===0){
    //求乘积
	s*=i;
  }
  i++;
}while(i<=20);
console.log(s);
*/

//练习：使用do-while，无限循环弹出提示框，要求用户输入密码，如果输入的密码是123456，则结束循环。
//04_dowhile.html
/*
//声明变量用于记录次数
var i=0;
do{
  //每输入一次，i就加1
  i++;
  //用户在输入之前，判断是否超过了4次，如果超过了，就不允许再次输入
  //1 2 3 4
  if(i>4){
     alert('lock');
	 break;
  }
  var str=prompt('input password');
  //判断输入是否正确
  if(str==='123456'){	 
    //结束循环
	break;
  }
  
}while(true);
*/
var i=0;
do{
  i++;
  if(i>4){
    alert('lock');
	break;
  }
  var str=prompt('input password');
  
}while(str!=='123456');//判断是否正确
//条件为false就会结束循环  '123456'
// 如果用户输入正确，则结束循环
//条件为true会继续循环
// 如果用户输入不正确，会继续循环   '888888'





