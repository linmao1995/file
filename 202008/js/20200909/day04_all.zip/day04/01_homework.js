/*
//判断一个人的成绩
var score=143;
//先排除0~100以外的成绩
if(score<0 || score>100){
  console.log('非法的成绩');
}else{
  //0~100之间
  //让分数除以10，再取整，缩小每个分数段范围
  //90~100     9 10
  //80~90以下  8
  //70~80以下  7
  switch( parseInt(score/10) ){
    case 10:
	case 9:
      console.log('优秀');
	  break;
    case 8:
	  console.log('良好');
	  break;
	case 7:
      console.log('中等');
	  break;
	case 6:
	  console.log('及格');
	  break;
	default:
	  console.log('不及格');
  }
}
*/

//弹出提示框，分别输入单价和数量
var price=prompt('input price');
var num=prompt('input number');
//卡内余额是1200
var money=1200;
//计算出总价
var total=price*num;
console.log(total);
//如果满1000打九折
if(total>=1000){
  total*=0.9;
}
console.log(total);
//如果足以支付
if(money>=total){
  alert('pay success');
}else{
  alert('pay error');
}