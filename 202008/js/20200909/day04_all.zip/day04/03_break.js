//循环打印1~10
/*
var i=1;
while(true){
  console.log(i);
  //当i为10的时候，强制结束  break
  if(i===10){
    break;
  }
  i++;
}
*/
//练习：使用死循环计算11~20之间所有整数的乘积
var i=11;
//初始化变量，记录乘积
var s=1;
while(true){
  //i代表11~20之间所有整数
  //求乘积,把所有整数乘以到s中
  //1*11*12*13...*20
  s*=i;
  //当i为20的时候，强制结束循环
  if(i===20){
    break;
  }
  i++;
}
console.log(s);






