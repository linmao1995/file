var str1='1';//字面量
/*
//包装为字符串对象，会将数据强制转为字符串
var str2=new String(1);
var str3=String(true);
//console.log(str3,typeof str3);
//console.log(str2, typeof str2);
//console.log(str1+2);
//console.log(str2+2);

var arr=['a','b','c'];
//方法：通过对象调用
console.log( arr.toString() );
//函数：单独调用，和对象没关系
console.log( String(arr) );

//转义单引号为普通字符
console.log('Ran\'s playing');
console.log('a\nd');
console.log('a\tb');//制表符：多个连续空格
*/
//C:/Users/web
console.log('C:\\Users\\web');
console.log('C:/Users/web');
