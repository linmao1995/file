/*
console.log( Math.random() );
console.log( Math.random() );
console.log( Math.random() );
*/
//0~1  *  10

var arr=['郭少强','刘家乐','杨超群','赵志豪','周梓涵'];
//0~4
//0~1 * 5  0~4.x  取整parseInt   0~4
var n=parseInt( Math.random()*5 );
console.log(n, arr[n]);


