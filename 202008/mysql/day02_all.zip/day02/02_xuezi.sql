#设置客户端连接服务器端的编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xuezi;
#创建数据库，设置存储的编码
CREATE DATABASE xuezi CHARSET=UTF8;
#进入数据库
USE xuezi;
#创建保存数据的表
CREATE TABLE laptop(
  lid INT primary key,
  title VARCHAR(128),
  price DECIMAL(7,2),   #99999.99
  stockCount SMALLINT,
  shelfTime DATE,
  isIndex BOOLEAN
);
#插入数据
INSERT INTO laptop VALUES(8,'小米Air',3799,30,'2019-12-1',1);
INSERT INTO laptop VALUES('2','ThinkPadE470','3199','50','2016-1-1','0');
INSERT INTO laptop VALUES(6,'荣耀400',4199,100,'2020-3-1',1);