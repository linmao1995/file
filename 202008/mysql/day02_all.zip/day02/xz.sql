#设置客户端连接服务器端的编码为UTF8
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建一个新的数据库，设置存储的编码为UTF8
CREATE DATABASE xz CHARSET=UTF8;
#进入数据库
USE xz;
#创建数据表
CREATE TABLE user(
  uid INT,
  uname VARCHAR(16),
  upwd VARCHAR(32),
  email VARCHAR(32),
  phone VARCHAR(11),
  userName VARCHAR(8),
  regTime VARCHAR(10),   #2020-12-25
  isOnline VARCHAR(1)    #y/n
);
#插入数据
INSERT INTO user VALUES('1','ran','123456','ran@qq.com','18112345678','然哥','2020-8-1','y');
INSERT INTO user VALUES('2','dong','888888','dong@qq.com','15845459632','东东','2020-1-1','n');
INSERT INTO user VALUES('3','shan','666666','shan@qq.com','19974747474','然然','2019-12-1','n');
#修改数据
UPDATE user SET email='ssd@163.com',isOnline='y' WHERE uid='3';
UPDATE user SET upwd='333333',phone='17612345987',regTime='2020-9-2' WHERE  uid='1';
#删除数据
DELETE FROM user WHERE uid='2';
#查询数据
SELECT * FROM user;

