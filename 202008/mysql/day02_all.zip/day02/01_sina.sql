#设置客户端连接服务器端的编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS sina;
#创建数据库，设置存储的编码
CREATE DATABASE sina CHARSET=UTF8;
#进入数据库
USE sina;
#创建保存数据的表
CREATE TABLE news(
  nid INT,
  title VARCHAR(32),
  ctime VARCHAR(10),
  origin VARCHAR(8),
  detail VARCHAR(5000)
);
#插入数据
INSERT INTO news VALUES('1','然哥今晨抵达非洲女友家','2020-9-2','达内日报','详情一');
INSERT INTO news VALUES('2','特朗普死于疫情','2020-9-3','纽约时报','详情二');
INSERT INTO news VALUES('3','然哥爆料七年日本工作经历','2020-9-4','东京日报','详情三');
#修改数据
UPDATE news SET ctime='2020-10-1' WHERE nid='3';
#删除数据
DELETE FROM news WHERE nid='2';