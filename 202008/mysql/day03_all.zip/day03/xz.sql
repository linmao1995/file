#设置客户端连接服务器端的编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS xz;
#创建数据库，设置编码
CREATE DATABASE xz CHARSET=UTF8;
#进入数据库
USE xz;
#创建保存笔记本类别的表
CREATE TABLE family(
  fid INT PRIMARY KEY,
  fname VARCHAR(16) UNIQUE NOT NULL
);
#插入数据
INSERT INTO family VALUES
(10,'联想'),
(20,'戴尔'),
(30,'小米');
#单独插入一条数据测试NULL是否允许
INSERT INTO family VALUES(40,'华为');
INSERT INTO family VALUES(50,'苹果');
#创建保存笔记本数据的表
CREATE TABLE laptop(
  lid INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(128) UNIQUE,
  price DECIMAL(7,2) NOT NULL DEFAULT 3000,  #99999.99
  spec VARCHAR(64) NOT NULL,
  detail VARCHAR(5000),
  shelfTime DATE,
  isOnsale BOOLEAN DEFAULT 1,  #1是  0否
  familyId INT,
  #将familyId作为外键，取值范围到family表的fid列
  foreign key(familyId) references family(fid)
);
#插入数据
INSERT INTO laptop VALUES(1,'小米Air',3799,'开发版','详情1','2020-1-1',1,30);
INSERT INTO laptop VALUES(2,'燃7000',4199,'设计版','详情2','2020-2-1',1,20);
INSERT INTO laptop VALUES(3,'燃8000',4399,'设计版2','详情3','2020-2-1',0,20);
INSERT INTO laptop VALUES(4,NULL,4399,'设计版2','详情4','2020-3-1',0,10);
INSERT INTO laptop VALUES(15,NULL,DEFAULT,'设计版2','详情4',DEFAULT,DEFAULT,10);
INSERT INTO laptop(lid,title,spec,price) VALUES(6,'Apple pro','游戏本',12999);
INSERT INTO laptop(lid,title,spec,price) VALUES(NULL,'Apple Air','游戏本',6199);