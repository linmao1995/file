#设置客户端连接服务器端编码
SET NAMES UTF8;
#丢弃数据库，如果存在
DROP DATABASE IF EXISTS tedu;
#创建数据库，设置存储的编码
CREATE DATABASE tedu CHARSET=UTF8;
#进入数据库
USE tedu;
#创建保存部门数据的表
CREATE TABLE dept(
  did INT PRIMARY KEY AUTO_INCREMENT,
  dname VARCHAR(8) UNIQUE
);
#插入数据
INSERT INTO dept VALUES(10,'研发部');
INSERT INTO dept VALUES(20,'市场部');
INSERT INTO dept VALUES(30,'运营部');
INSERT INTO dept VALUES(40,'测试部');
#创建保存员工数据的表
CREATE TABLE emp(
  eid INT PRIMARY KEY AUTO_INCREMENT,
  ename VARCHAR(16) NOT NULL,
  sex BOOLEAN DEFAULT 1,  #1-男  0-女
  birthday DATE,
  salary DECIMAL(7,2),   #99999.99
  deptId INT,
  FOREIGN KEY(deptId) REFERENCES dept(did)
);
#插入数据
INSERT INTO emp VALUES(NULL,'gongjinglong',1,'1990-5-5',6000,20);
INSERT INTO emp VALUES(NULL,'daixiangyu',0,'1991-8-20',7000,10);
INSERT INTO emp VALUES(NULL,'dujiang',1,'1995-10-20',3000,30);
INSERT INTO emp VALUES(NULL,'wuxiaoxing',0,'1992-3-20',5000,10);
INSERT INTO emp VALUES(NULL,'wangtao',1,'1993-12-3',8000,20);
INSERT INTO emp VALUES(NULL,'liuhaonan',1,'1991-1-3',4000,10);
INSERT INTO emp VALUES(NULL,'xiongjie',1,'1990-12-3',10000,10);
INSERT INTO emp VALUES(NULL,'dahaozheng',1,'1994-12-3',6000,30);
INSERT INTO emp VALUES(NULL,'mazhengrui',1,'1991-12-3',9000,10);
INSERT INTO emp VALUES(NULL,'range',0,'1995-12-3',10000,20);
INSERT INTO emp VALUES(NULL,'liankun',1,'1993-12-3',8000,30);
INSERT INTO emp VALUES(NULL,'wangxiaomin',0,'1992-12-3',12000,10);
INSERT INTO emp VALUES(NULL,'zhuwentao',0,'1989-12-3',8000,10);
INSERT INTO emp VALUES(NULL,'hanchengyuan',1,'1988-12-3',10000,10);
INSERT INTO emp VALUES(NULL,'liuyuxi',1,'1993-12-3',22000,NULL);
