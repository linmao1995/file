const http=require('http');
const fs=require('fs');
//创建web服务器
const app=http.createServer();
//设置端口
app.listen(8080);
//接受请求，并作出响应
app.on('request',(req,res)=>{
  if(req.url==='/index'){
    res.writeHead(200,{
	  'Content-Type':'text/html;charset=utf-8'
	});
	res.write('<h2>这是首页</h2>');
  }else if(req.url==='/list'){
    //读取1.html文件中的数据
	let data=fs.readFileSync('./1.html');
	//把读取到的数据作为响应的内容
	//隐式将读取到的buffer数据转换为字符串
	res.write(data);
  }else if(req.url==='/study'){
    //跳转
	res.writeHead(302,{
	  Location:'http://www.tmooc.cn'
	});
  }else{
    res.writeHead(404);
	res.write('not found');
  }

  //无论响应哪些，最终都要结束发送
  res.end();
});