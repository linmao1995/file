const express=require('express');
//创建路由器对象
const r=express.Router();
//往路由器对象中添加路由
//用户列表 get /list
r.get('/list',(req,res)=>{
  res.send('这是用户列表');
});
//导出路由器对象
module.exports=r;