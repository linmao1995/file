const express=require('express');
//引入用户路由器
const userRouter=require('./user.js');
const app=express();
app.listen(8080);

//把路由器挂载到web服务器
//参数1：给所有URL添加的前缀，路由中URL访问必须加前缀
//    /user/list
//参数2：要挂载的路由器
app.use('/user',userRouter);
