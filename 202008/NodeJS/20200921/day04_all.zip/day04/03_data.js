const express=require('express');
//引入查询字符串模块
const querystring=require('querystring');
const app=express();
app.listen(8080);

//响应搜索网页的路由  get  /search
app.get('/search',(req,res)=>{
  res.sendFile(__dirname+'/search.html');
});
//练习：根据表单提交的请求创建对应的路由
//get  /mysearch   响应'搜索成功'
app.get('/mysearch',(req,res)=>{
  //获取请求的URL，请求的方法
  console.log(req.url);
  console.log(req.method);
  //获取以查询字符串传递的数据，格式为对象
  console.log( req.query );
  res.send('搜索成功，您要搜索的关键字：'+req.query.keyword);
});

//响应登录页面的路由  get  /login
app.get('/login',(req,res)=>{
  res.sendFile(__dirname+'/login.html');
});
//根据表单的请求创建对应的路由
//post  /mylogin
app.post('/mylogin',(req,res)=>{
  //获取post传递的数据
  //以流的方式传递，通过事件获取
  //一旦有数据流入，通过回调函数获取
  req.on('data',(chunk)=>{
    //chunk 分段的数据，格式为buffer
	//console.log(chunk);
	//转为字符串,格式为查询字符串
	console.log( String(chunk) ); 
	//解析为对象
	let obj=querystring.parse( String(chunk) );
	console.log(obj);
	res.send('登录成功，欢迎：'+obj.uname);
  });
  
});

//添加查看包的详情 路由，传递包的名称
//get  /package
app.get('/package/:pname',(req,res)=>{
  //:pname 设置形参的名称，传递的数据被pname所接收
  //获取路由传参的数据
  console.log( req.params );
  res.send('这是包的详情介绍');
});

//练习：创建添加到购物车路由(get  /shopping)，使用路由传参传递商品的编号(lid)和价格(price)，最后响应  '商品编号：xx   商品价格：xx'
app.get('/shopping/:lid/:price',(req,res)=>{
  console.log(req.params);
  res.send(`
	商品编号：${req.params.lid}  <br>
	商品数量：${req.params.price}
  `);
});








