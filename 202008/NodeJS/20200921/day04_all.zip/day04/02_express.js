//引入express包，属于第三方模块
const express=require('express');
//console.log(express);
//创建web服务器
const app=express();
//设置端口
app.listen(8080);

//路由
//首页的路由
//请求方法:get   请求URL: /index
app.get('/index',(req,res)=>{
  //res 响应的对象，比之前http中的方法更多
  res.send('<h2>这是首页</h2>'); //设置响应内容并发送
});
//练习：创建获取用户信息的路由  请求的方法:get  请求的URL:/user，响应‘这是用户信息’
app.get('/user',(req,res)=>{
  res.send('这是用户信息');
});
//用户列表路由  get  /list
//响应1.html
app.get('/list',(req,res)=>{
  //响应的文件需要使用绝对路径
  res.sendFile(__dirname+'/1.html');
});
//获取当前模块的绝对路径
//console.log(__dirname);
//练习：添加商品详情路由  get   /detail   响应2.html
app.get('/detail',(req,res)=>{
  res.sendFile(__dirname+'/2.html');
});

//路由  get  /study  
//跳转到 http://www.tmooc.cn
app.get('/study',(req,res)=>{
  res.redirect('http://www.tmooc.cn');
});
//路由  get  /
//跳转到首页   /index
app.get('/',(req,res)=>{
  res.redirect('/index');
});






