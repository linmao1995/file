//创建Buffer
let buf=Buffer.alloc(6,'然哥');
console.log(buf);
console.log( String(buf), buf.toString() );