var a=1;
function fn(){
  return 2;
}
//报错
//console.log( global.a );
//console.log( global.fn() );