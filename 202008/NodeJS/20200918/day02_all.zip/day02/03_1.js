let obj=require('./03_2');
console.log(obj);
console.log(obj.add(3,5));