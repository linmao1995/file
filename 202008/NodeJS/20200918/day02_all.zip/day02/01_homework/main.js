//引入circle.js模块
//如果模块后缀名是js，可以省略后缀名
let circle=require('./circle.js');
console.log(circle);
//调用导出的函数
//console.log( circle.len(5).toFixed(2) );
//console.log( circle.area(5).toFixed(2) );