function add(a,b){
  return a+b;
}
//导出
module.exports={
  add: add
}